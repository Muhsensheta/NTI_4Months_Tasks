/*
 * EXT0_config.h
 *
 *  Created on: ١٦‏/٠٦‏/٢٠٢٣
 *      Author: houras
 */

#ifndef EXT_INT0_EXT0_CONFIG_H_
#define EXT_INT0_EXT0_CONFIG_H_

#define LOW_LEVEL_CHANGE       0
#define ANY_LEVEL_CHANGE       1
#define RAISING_EDGE_CHANGE    2
#define FALING_EDGE_CHANGE     3



#endif /* EXT_INT0_EXT0_CONFIG_H_ */
