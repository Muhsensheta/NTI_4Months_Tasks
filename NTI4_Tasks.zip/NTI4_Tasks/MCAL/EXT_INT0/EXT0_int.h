/*
 * EXT0_int.h
 *
 *  Created on: ١٦‏/٠٦‏/٢٠٢٣
 *      Author: houras
 */

#ifndef EXT_INT0_EXT0_INT_H_
#define EXT_INT0_EXT0_INT_H_

void M_void_EXT0_INIT();
void M_void_EXT0_Enable(u8 Sense);
void M_void_EXT0_disable();
void M_void_EXT0_SetCallback(void (*ptr)());



#endif /* EXT_INT0_EXT0_INT_H_ */
