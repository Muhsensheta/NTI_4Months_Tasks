/*
 * TIMER0_config.h
 *
 *  Created on: ١٨‏/٠٦‏/٢٠٢٣
 *      Author: houras
 */

#ifndef TIMER_TIMER_CONFIG_H_
#define TIMER_TIMER_CONFIG_H_

#define TIMER0_MODE    TIMER0_FAST_PWM_MODE
#define TIMER0_PRESCALLER    TIMER0_PRESCALER_1024


#endif /* TIMER0_TIMER_CONFIG_H_ */
