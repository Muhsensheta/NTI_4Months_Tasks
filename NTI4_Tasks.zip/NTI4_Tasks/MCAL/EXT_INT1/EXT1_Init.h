/*
 * EXT1_Init.h
 *
 *  Created on: ١٦‏/٠٦‏/٢٠٢٣
 *      Author: houras
 */

#ifndef EXT_INT1_EXT1_INIT_H_
#define EXT_INT1_EXT1_INIT_H_

void M_void_EXT1_INIT();
void M_void_EXT1_Enable(u8 Sense);
void M_void_EXT1_disable();
void M_void_EXT1_SetCallback(void (*ptr)());


#endif /* EXT_INT1_EXT1_INIT_H_ */
