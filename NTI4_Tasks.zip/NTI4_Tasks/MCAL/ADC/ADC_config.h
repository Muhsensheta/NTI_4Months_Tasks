/*
 * ADC_config.h
 *
 *  Created on: ١٧‏/٠٦‏/٢٠٢٣
 *      Author: houras
 */

#ifndef ADC_ADC_CONFIG_H_
#define ADC_ADC_CONFIG_H_



#endif /* ADC_ADC_CONFIG_H_ */
