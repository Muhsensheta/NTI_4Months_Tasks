/*
 * DIO_config.h
 *
 *  Created on: ١٠‏/٠٦‏/٢٠٢٣
 *      Author: houras
 */

#ifndef DIO_DIO_CONFIG_H_
#define DIO_DIO_CONFIG_H_



#endif /* DIO_DIO_CONFIG_H_ */
