/*
 * TIMER1_config.h
 *
 *  Created on: ٢٦‏/٠٦‏/٢٠٢٣
 *      Author: houras
 */

#ifndef TIMER1_TIMER1_CONFIG_H_
#define TIMER1_TIMER1_CONFIG_H_



#endif /* TIMER1_TIMER1_CONFIG_H_ */
