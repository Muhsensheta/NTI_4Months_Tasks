/*
 * GIE_priv.h
 *
 *  Created on: ١٦‏/٠٦‏/٢٠٢٣
 *      Author: houras
 */

#ifndef GIE_GIE_PRIV_H_
#define GIE_GIE_PRIV_H_

#define SREG_REG  *((volatile u8 *)0x5f)
#define I_BIT   7

#endif /* GIE_GIE_PRIV_H_ */
