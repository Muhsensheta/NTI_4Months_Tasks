/*
 * GIE_config.h
 *
 *  Created on: ١٦‏/٠٦‏/٢٠٢٣
 *      Author: houras
 */

#ifndef GIE_GIE_CONFIG_H_
#define GIE_GIE_CONFIG_H_



#endif /* GIE_GIE_CONFIG_H_ */
