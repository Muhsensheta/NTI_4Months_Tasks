/*
 * GIE_int.h
 *
 *  Created on: ١٦‏/٠٦‏/٢٠٢٣
 *      Author: houras
 */

#ifndef GIE_GIE_INT_H_
#define GIE_GIE_INT_H_

void M_void_GIE_Enable();
void M_void_GIE_disable();

#endif /* GIE_GIE_INT_H_ */
