/*
 * KEYPAD_init.h
 *
 *  Created on: ١٢‏/٠٦‏/٢٠٢٣
 *      Author: houras
 */

#ifndef KEYPAD_KEYPAD_INIT_H_
#define KEYPAD_KEYPAD_INIT_H_

#define NON_PRESSED_KEY  0xff

void H_KP_void_init();
u8 H_KP_u8_GetPressedKey();

#endif /* KEYPAD_KEYPAD_INIT_H_ */
