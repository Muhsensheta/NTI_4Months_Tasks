/*
 * KEYPAD_priv.h
 *
 *  Created on: ٠٢‏/٠٢‏/٢٠٢٣
 *      Author: houras
 */

#ifndef KEYPAD_KEYPAD_PRIV_H_
#define KEYPAD_KEYPAD_PRIV_H_



#endif /* KEYPAD_KEYPAD_PRIV_H_ */
