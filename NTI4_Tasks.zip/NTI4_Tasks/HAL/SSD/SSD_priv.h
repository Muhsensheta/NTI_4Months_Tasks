/*
 * SSD_priv.h
 *
 *  Created on: ١٠‏/٠٦‏/٢٠٢٣
 *      Author: houras
 */

#ifndef SSD_SSD_PRIV_H_
#define SSD_SSD_PRIV_H_



#endif /* SSD_SSD_PRIV_H_ */
