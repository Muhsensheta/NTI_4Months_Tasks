/*
 * SSD_init.h
 *
 *  Created on: ١٠‏/٠٦‏/٢٠٢٣
 *      Author: houras
 */

#ifndef SSD_SSD_INIT_H_
#define SSD_SSD_INIT_H_

void H_SSD_void_Init(void);
void H_SSD_void_display(u8 number);



#endif /* SSD_SSD_INIT_H_ */
