/*
 * PB_config.h
 *
 *  Created on: ١٠‏/٠٦‏/٢٠٢٣
 *      Author: houras
 */

#ifndef PUSH_B_PB_CONFIG_H_
#define PUSH_B_PB_CONFIG_H_

#define PB1_ROW_PORT  PORTC
#define PB1_ROW_PIN  PIN5

#define PB1_COLM_PORT  PORTD
#define PB1_COLM_PIN  PIN7

#define PB2_PORT  PORTA
#define PB2_PIN   PIN0


#endif /* PUSH_B_PB_CONFIG_H_ */
