/*
 * PB_init.h
 *
 *  Created on: ١٠‏/٠٦‏/٢٠٢٣
 *      Author: houras
 */

#ifndef PUSH_B_PB_INIT_H_
#define PUSH_B_PB_INIT_H_

void H_void_PB1_init();
void H_void_PB_Read(u8 *read);


#endif /* PUSH_B_PB_INIT_H_ */
