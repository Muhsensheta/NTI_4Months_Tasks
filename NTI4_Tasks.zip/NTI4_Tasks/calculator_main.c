/*
 * calculator_main.c
 *
 *  Created on: ٠٦‏/٠٧‏/٢٠٢٣
 *      Author: houras
 */
#if (0)

#include <util/delay.h>
#include "BIT_MATH.h"
#include "STD_TYPES.h"
#include "DIO_init.h"
#include "SSD_init.h"
#include"PB_init.h"
#include "LCD_int.h"
#include "KEYPAD_init.h"
#include "EXT1_Init.h"
#include "EXT1_config.h"
#include "EXT0_int.h"
#include "GIE_int.h"
#include "ADC_Init.h"
#include "TIMER_int.h"
#include "TIMER_priv.h"
#include "TIMER1_priv.h"
#include "TIMER1_int.h"

int main()
{
	u16 first_op=0;
	u16 sec_op=0;
	u32 result=0;
	u8 operation;
	u8 flag =0;
	u8 ZeroFlag=0;
	u8 PressedKey=0xff;
      H_LCD_void_Init();
      H_KP_void_init();

	while (1)
	{
		/*H_LCD_void_sendString(" hello ");

		_delay_ms(500);
		H_LCD_void_clear();
		H_LCD_void_sendData('2');
		_delay_ms(500);
		H_LCD_void_clear();*/
		do {
			PressedKey = H_KP_u8_GetPressedKey();
		   }while(PressedKey==0xff );
		if ((PressedKey=='+')||(PressedKey=='-')||(PressedKey=='*')||(PressedKey=='/'))
			{
				operation=PressedKey;
				H_LCD_void_sendData(operation);
				flag=1;
			}
			else if (PressedKey=='=')
			{
				H_LCD_void_sendData('=');

					switch(operation)
					{
					case '+' :
						result=first_op + sec_op;
						break;

					case '-' :
						result=first_op - sec_op;
						break;
					case '*' :
						result=first_op * sec_op;
						break;
					case '/' :
						if(sec_op !=0)
						{
						result=first_op / sec_op;

						}
						else{
							H_LCD_void_clear();
							H_LCD_void_sendString("devide by zero");
							flag=0;
							first_op=0;
							sec_op=0;
							ZeroFlag=1;
							result=0;
							break;
						}
						break;
					}
					if (ZeroFlag==0)
					{
						H_LCD_void_sendIntNum(result);
					}
				}

				else if (PressedKey =='C')
				{
					H_LCD_void_clear();
					flag=0;
					first_op=0;
					sec_op=0;
					ZeroFlag=0;

				}
				else if(flag==0)
				{
					first_op=PressedKey+(first_op*10);
					H_LCD_void_sendIntNum(PressedKey);


				}
				else if(flag==1)
				{
					sec_op=PressedKey+(sec_op*10);
					H_LCD_void_sendIntNum(PressedKey);

				}
	}

	return 0;
}

#endif


